//
//  YDTNative.h
//  YDTNative
//
//  Created by roger on 2022/2/19.
//

#import <Foundation/Foundation.h>

//! Project version number for YDTNative.
FOUNDATION_EXPORT double YDTNativeVersionNumber;

//! Project version string for YDTNative.
FOUNDATION_EXPORT const unsigned char YDTNativeVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <YDTNative/PublicHeader.h>


