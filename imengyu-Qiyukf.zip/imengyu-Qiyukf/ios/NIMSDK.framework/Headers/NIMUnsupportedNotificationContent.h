//
//  NIMUnsupportedNotificationContent.h
//  NIMLib
//
//  Created by Netease.
//  Copyright © 2016 Netease. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NIMUnsupportedNotificationContent : NIMNotificationContent
@end


NS_ASSUME_NONNULL_END